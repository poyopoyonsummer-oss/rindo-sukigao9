window.MEMBERS = [
  {
    "name": "つばき",
    "group": "夢喰NEON・XP!A",
    "image": "https://yumekuineon-official.com/wp-content/uploads/2026/03/%E5%A4%A2%E5%96%B0NEON%E3%82%A2%E3%83%BC%E5%86%99_%E3%81%A4%E3%81%B0%E3%81%8D.jpg"
  },
  {
    "name": "さく",
    "group": "夢喰NEON",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/saku/"
  },
  {
    "name": "なめ",
    "group": "夢喰NEON・XP!A",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/name-xpia/"
  },
  {
    "name": "きょうへい",
    "group": "夢喰NEON",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/きょうへい/"
  },
  {
    "name": "しょうた",
    "group": "夢喰NEON",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/しょうた/"
  },
  {
    "name": "はやと",
    "group": "夢喰NEON・Untitle",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/きょうへい-2-2/"
  },
  {
    "name": "ないち",
    "group": "XP!A",
    "image": "https://ee9ui7zg9r5.exactdn.com/wp-content/uploads/2024/07/XPA%E3%82%A2%E3%83%BC%E5%86%99%E3%81%AA%E3%81%84%E3%81%A1-1.jpg?strip=all"
  },
  {
    "name": "りう",
    "group": "XP!A",
    "image": "https://ee9ui7zg9r5.exactdn.com/wp-content/uploads/2024/07/XPA%E3%82%A2%E3%83%BC%E5%86%99%E3%82%8A%E3%81%86-1.jpg?strip=all"
  },
  {
    "name": "りんたろ。",
    "group": "XP!A",
    "image": "https://ee9ui7zg9r5.exactdn.com/wp-content/uploads/2024/07/XPA%E3%82%A2%E3%83%BC%E5%86%99%E3%82%8A%E3%82%93%E3%81%9F%E3%82%8D-1.jpg?strip=all"
  },
  {
    "name": "はく",
    "group": "XP!A",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/haku-xpia/"
  },
  {
    "name": "みお",
    "group": "XP!A",
    "image": "https://ee9ui7zg9r5.exactdn.com/wp-content/uploads/2024/07/XPA%E3%82%A2%E3%83%BC%E5%86%99%E3%81%BF%E3%81%8A-2.jpg?strip=all"
  },
  {
    "name": "けん",
    "group": "XP!A",
    "image": "https://ee9ui7zg9r5.exactdn.com/wp-content/uploads/2024/07/XPA%E3%82%A2%E3%83%BC%E5%86%99%E3%81%91%E3%82%93-2.jpg?strip=all"
  },
  {
    "name": "えつや",
    "group": "#らぶしっく・▷せーぶぽいんと",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/etsuya/"
  },
  {
    "name": "ふゆみ",
    "group": "▷せーぶぽいんと・#Luvless",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/fuyumi/"
  },
  {
    "name": "かなめ",
    "group": "▷せーぶぽいんと",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/kaname/"
  },
  {
    "name": "あむ",
    "group": "▷せーぶぽいんと",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/amu/"
  },
  {
    "name": "ゆき",
    "group": "▷せーぶぽいんと・#Luvless",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/yuki/"
  },
  {
    "name": "とあ",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "ねる",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "うみ",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "らん",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "そう",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "たく",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "めあ",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "ひろ",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "てん",
    "group": "ホローホログラム",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "さくら",
    "group": "#らぶしっく",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/sakura/"
  },
  {
    "name": "うと",
    "group": "XP!A・#らぶしっく",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/uto-xpia/"
  },
  {
    "name": "ゆそん",
    "group": "#らぶしっく",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/yuson/"
  },
  {
    "name": "たいよう",
    "group": "#らぶしっく",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/taiyou/"
  },
  {
    "name": "はやて",
    "group": "#らぶしっく",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/hayate/"
  },
  {
    "name": "りょう",
    "group": "#らぶしっく",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/ryo/"
  },
  {
    "name": "さつき",
    "group": "#らぶしっく",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/satsuki/"
  },
  {
    "name": "たろ",
    "group": "#らぶしっく",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/taro/"
  },
  {
    "name": "こうた",
    "group": "UNDEЯ DOG",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/kota/"
  },
  {
    "name": "はも",
    "group": "UNDEЯ DOG",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/hamo/"
  },
  {
    "name": "せな",
    "group": "UNDEЯ DOG・DeXeultio",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/sena/"
  },
  {
    "name": "伊藤。",
    "group": "UNDEЯ DOG",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/ito/"
  },
  {
    "name": "こむぎ",
    "group": "UNDEЯ DOG",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/komugi/"
  },
  {
    "name": "けい",
    "group": "UNDEЯ DOG",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/kei/"
  },
  {
    "name": "はると",
    "group": "UNDEЯ DOG",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/haruto/"
  },
  {
    "name": "あゆむ",
    "group": "UNDEЯ DOG",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/ayumu/"
  },
  {
    "name": "ゆうま",
    "group": "#Luvless",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/yuuma/"
  },
  {
    "name": "ふゆみ",
    "group": "▷せーぶぽいんと・#Luvless",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/fuyumi/"
  },
  {
    "name": "ゆたか",
    "group": "#Luvless",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/yutaka/"
  },
  {
    "name": "いぶき",
    "group": "#Luvless",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/ibuki/"
  },
  {
    "name": "ふうま",
    "group": "#Luvless",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/fuuma/"
  },
  {
    "name": "いっせい",
    "group": "#Luvless",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/issei/"
  },
  {
    "name": "たいちん",
    "group": "DeXeultio",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/taichin-dexeultio/"
  },
  {
    "name": "だいち",
    "group": "DeXeultio",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/daichi/"
  },
  {
    "name": "あさひ",
    "group": "DeXeultio",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/asahi/"
  },
  {
    "name": "こんちゃん",
    "group": "DeXeultio",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/konchan/"
  },
  {
    "name": "れん",
    "group": "DeXeultio",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "せら",
    "group": "DeXeultio",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "りゅうが",
    "group": "DeXeultio",
    "image": "images/ryuga.jpeg"
  },
  {
    "name": "つかさ",
    "group": "ki:ki",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/tsukasa/"
  },
  {
    "name": "なお",
    "group": "ki:ki",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/nao/"
  },
  {
    "name": "うた",
    "group": "ki:ki",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/uta/"
  },
  {
    "name": "あとむ",
    "group": "ki:ki",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/atom/"
  },
  {
    "name": "しき",
    "group": "ki:ki",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/shiki/"
  },
  {
    "name": "ひゅうが",
    "group": "ki:ki",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/hyuga/"
  },
  {
    "name": "あらた",
    "group": "ki:ki",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/arata/"
  },
  {
    "name": "りき",
    "group": "Ⱥstral",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/riki/"
  },
  {
    "name": "じん",
    "group": "Ⱥstral",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/jin/"
  },
  {
    "name": "うぃる",
    "group": "Ⱥstral",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/will/"
  },
  {
    "name": "つばさ",
    "group": "Ⱥstral",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/tsubasa/"
  },
  {
    "name": "れい",
    "group": "Ⱥstral",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "みなと",
    "group": "UNDEЯ DOG・Ⱥstral",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/minato/"
  },
  {
    "name": "なぎさ",
    "group": "Ⱥstral",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/nagisa/"
  },
  {
    "name": "らいと",
    "group": "夢喰NEON・Untitle",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/raito/"
  },
  {
    "name": "りゅうせい",
    "group": "Untitle",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/ryusei/"
  },
  {
    "name": "あかね",
    "group": "Untitle",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/akane/"
  },
  {
    "name": "りお",
    "group": "Untitle",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/rio/"
  },
  {
    "name": "なつ",
    "group": "Untitle",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/natsu/"
  },
  {
    "name": "ひかる",
    "group": "DeXeultio・Untitle",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/hikaru/"
  },
  {
    "name": "らいむ",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "ゆり",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "えいじ",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "りゅうき",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "くれぁ",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "ゆに",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "りと",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "Rim",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "ぜん",
    "group": "diabell",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "タイマイ",
    "group": "じわっときてる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "禊",
    "group": "じわっときてる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "梅",
    "group": "じわっときてる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "よきき",
    "group": "じわっときてる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "なつめ",
    "group": "じわっときてる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "しの",
    "group": "すきゃんどーる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "れお",
    "group": "すきゃんどーる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "かぐや",
    "group": "すきゃんどーる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "あさと",
    "group": "すきゃんどーる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "りゅーと",
    "group": "すきゃんどーる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "そらん",
    "group": "すきゃんどーる",
    "image": "https://image.thum.io/get/width/700/crop/900/noanimate/https://rindo-entertainment.co.jp/talent/"
  },
  {
    "name": "あまと",
    "group": "提供写真",
    "image": "images/amato.jpeg"
  },
  {
    "name": "りゅうが",
    "group": "提供写真",
    "image": "images/ryuga.jpeg"
  },
  {
    "name": "ゆの",
    "group": "提供写真",
    "image": "images/yuno.jpeg"
  },
  {
    "name": "たくみん",
    "group": "提供写真",
    "image": "images/takumin.jpeg"
  }
];
