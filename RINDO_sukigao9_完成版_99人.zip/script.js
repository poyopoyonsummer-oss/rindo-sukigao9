const allMembers = window.MEMBERS.map((m,i)=>({...m,id:i}));
const $ = s => document.querySelector(s);
const shuffle = a => [...a].sort(()=>Math.random()-.5);
let current=[], winners=[], queue=[], round=0, selected18=[], finalQueue=[], top9=[];

function avatar(m){
  if(m.image) return `<img class="photo" src="images/${m.image}" alt="${m.name}">`;
  const ch=[...m.name].filter(x=>x.trim())[0]||"♡";
  return `<div class="photo placeholder">${ch}</div>`;
}
function card(m, cls=""){
  return `<div class="person ${cls}" data-id="${m.id}">${avatar(m)}<div class="name">${m.name}</div><div class="group">${m.group}</div></div>`;
}
function setProgress(a,b){$("#phaseLabel").textContent=a;$("#progressLabel").textContent=b}

$("#startBtn").onclick=()=>{
  $("#start").classList.add("hidden");
  current=shuffle(allMembers); startRound1();
};

function startRound1(){
  round=1; winners=[]; queue=shuffle(current);
  setProgress("99 → 50","1 / 50");
  nextDuel();
}
function nextDuel(){
  if(round===1 && queue.length===1){winners.push(queue.pop());finishRound1();return}
  if(queue.length<2){finishRound1();return}
  const a=queue.shift(), b=queue.shift();
  renderDuel(a,b, round===1 ? "99人から50人を選ぶ" : "50人から25人を選ぶ");
}
function renderDuel(a,b,title){
  $("#battle").classList.remove("hidden");
  $("#battleArea").innerHTML=`<div class="battle-card"><h2>${title}</h2><div class="duel">${card(a)}${card(b)}</div></div>`;
  $("#battleArea").querySelectorAll(".person").forEach(el=>el.onclick=()=>{
    const id=Number(el.dataset.id), win=id===a.id?a:b;
    winners.push(win);
    const target=round===1?50:25;
    setProgress(round===1?"99 → 50":"50 → 25",`${winners.length} / ${target}`);
    setTimeout(nextDuel,100);
  });
}
function finishRound1(){
  current=winners; round=2; winners=[]; queue=shuffle(current);
  setProgress("50 → 25","0 / 25"); nextDuel2();
}
function nextDuel2(){
  if(queue.length<2){finishRound2();return}
  const a=queue.shift(),b=queue.shift();
  renderDuel(a,b,"50人から25人を選ぶ");
}
function finishRound2(){
  current=winners;
  $("#battle").classList.add("hidden");
  $("#select18").classList.remove("hidden");
  selected18=[]; renderSelect18();
}
function renderSelect18(){
  $("#selectCount").textContent=`${selected18.length} / 18`;
  $("#selectGrid").innerHTML=current.map(m=>card(m,selected18.includes(m.id)?"selected":"")).join("");
  $("#selectGrid").querySelectorAll(".person").forEach(el=>el.onclick=()=>{
    const id=Number(el.dataset.id);
    if(selected18.includes(id)) selected18=selected18.filter(x=>x!==id);
    else if(selected18.length<18) selected18.push(id);
    renderSelect18();
    $("#go9Btn").disabled=selected18.length!==18;
  });
}
$("#go9Btn").onclick=()=>{
  current=selected18.map(id=>allMembers.find(m=>m.id===id));
  $("#select18").classList.add("hidden");
  startFinal();
};

function startFinal(){
  finalQueue=shuffle(current); top9=[];
  $("#final").classList.remove("hidden"); nextFinal();
}
function nextFinal(){
  if(finalQueue.length<2){top9.push(...finalQueue);finalQueue=[];showResult();return}
  const a=finalQueue.shift(),b=finalQueue.shift();
  $("#finalProgress").textContent=`${top9.length} / 9`;
  $("#finalArea").innerHTML=`<div class="battle-card"><h2>18人からTOP9へ♡</h2><div class="duel">${card(a)}${card(b)}</div></div>`;
  $("#finalArea").querySelectorAll(".person").forEach(el=>el.onclick=()=>{
    const id=Number(el.dataset.id), win=id===a.id?a:b;
    top9.push(win);
    setTimeout(nextFinal,100);
  });
}
function showResult(){
  $("#final").classList.add("hidden"); $("#result").classList.remove("hidden");
  $("#resultGrid").innerHTML=top9.slice(0,9).map((m,i)=>`<div style="position:relative">${card(m)}<div class="rank">${i+1}</div></div>`).join("");
}
$("#retryBtn").onclick=()=>location.reload();
